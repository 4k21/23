import React, { useState } from 'react';
import { Crown, Users, Target, Award, Phone, Mail, Calendar, TrendingUp } from 'lucide-react';

function App() {
  const [activeSection, setActiveSection] = useState('home');

  const members = [
    {
      name: "Don Raze",
      role: "Глава семьи",
      status: "Легенда",
      image: "https://images.pexels.com/photos/1040881/pexels-photo-1040881.jpeg?auto=compress&cs=tinysrgb&w=400"
    },
    {
      name: "Marco Raze",
      role: "Заместитель",
      status: "Авторитет",
      image: "https://images.pexels.com/photos/1043474/pexels-photo-1043474.jpeg?auto=compress&cs=tinysrgb&w=400"
    },
    {
      name: "Sofia Raze",
      role: "Советник",
      status: "Влиятельная",
      image: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=400"
    },
    {
      name: "Alex Raze",
      role: "Исполнитель",
      status: "Надежный",
      image: "https://images.pexels.com/photos/1484794/pexels-photo-1484794.jpeg?auto=compress&cs=tinysrgb&w=400"
    }
  ];

  const achievements = [
    { icon: Crown, title: "Контроль территории", value: "15 районов", color: "text-yellow-400" },
    { icon: Users, title: "Участники семьи", value: "50+ человек", color: "text-red-400" },
    { icon: Target, title: "Успешные операции", value: "200+", color: "text-green-400" },
    { icon: TrendingUp, title: "Влияние в городе", value: "95%", color: "text-blue-400" }
  ];

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-black/80 backdrop-blur-md z-50 border-b border-red-800/30">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <Crown className="h-8 w-8 text-red-500" />
              <span className="text-2xl font-bold bg-gradient-to-r from-red-500 to-yellow-400 bg-clip-text text-transparent">
                RAZE FAMILY
              </span>
            </div>
            <div className="hidden md:flex space-x-8">
              {['home', 'about', 'members', 'news'].map((section) => (
                <button
                  key={section}
                  onClick={() => setActiveSection(section)}
                  className={`px-4 py-2 rounded-lg transition-all duration-300 ${
                    activeSection === section 
                      ? 'bg-red-600 shadow-lg shadow-red-600/30' 
                      : 'hover:bg-red-600/20'
                  }`}
                >
                  {section === 'home' && 'Главная'}
                  {section === 'about' && 'О нас'}
                  {section === 'members' && 'Участники'}
                  {section === 'news' && 'Новости'}
                </button>
              ))}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      {activeSection === 'home' && (
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-red-900/20 via-black to-yellow-900/20"></div>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(239,68,68,0.1),transparent_70%)]"></div>
          
          <div className="relative z-10 text-center max-w-4xl px-6">
            <div className="mb-8">
              <Crown className="h-20 w-20 text-yellow-400 mx-auto mb-6 animate-pulse" />
            </div>
            <h1 className="text-6xl md:text-8xl font-bold mb-6 bg-gradient-to-r from-red-500 via-yellow-400 to-red-500 bg-clip-text text-transparent animate-fade-in">
              RAZE FAMILY
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 mb-8 leading-relaxed">
              Самая влиятельная и могущественная семья на Majestic RP
            </p>
            <p className="text-lg text-gray-400 mb-12 max-w-2xl mx-auto">
              Мы контролируем улицы, защищаем своих и никогда не забываем предательства. 
              Наша власть построена на уважении, страхе и абсолютной лояльности.
            </p>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-16">
              {achievements.map((achievement, index) => (
                <div key={index} className="text-center group">
                  <achievement.icon className={`h-10 w-10 mx-auto mb-3 ${achievement.color} group-hover:scale-110 transition-transform`} />
                  <div className="text-2xl font-bold text-white">{achievement.value}</div>
                  <div className="text-sm text-gray-400">{achievement.title}</div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* About Section */}
      {activeSection === 'about' && (
        <section className="min-h-screen pt-24 px-6">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-5xl font-bold text-center mb-16 bg-gradient-to-r from-red-500 to-yellow-400 bg-clip-text text-transparent">
              История семьи RAZE
            </h2>
            
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <div className="bg-gradient-to-br from-red-900/30 to-black/50 p-8 rounded-2xl border border-red-800/30 backdrop-blur-sm">
                  <h3 className="text-2xl font-bold text-red-400 mb-4">Наши принципы</h3>
                  <ul className="space-y-3 text-gray-300">
                    <li className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                      <span>Семья превыше всего</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                      <span>Уважение через силу</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                      <span>Никаких предателей</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                      <span>Контроль территории</span>
                    </li>
                  </ul>
                </div>
                
                <div className="bg-gradient-to-br from-yellow-900/30 to-black/50 p-8 rounded-2xl border border-yellow-800/30 backdrop-blur-sm">
                  <h3 className="text-2xl font-bold text-yellow-400 mb-4">Наша власть</h3>
                  <p className="text-gray-300 leading-relaxed">
                    Семья Raze контролирует самые важные районы города. Наше влияние простирается 
                    от деловых кварталов до портовых доков. Мы не просто участники игры - мы создаем правила.
                  </p>
                </div>
              </div>
              
              <div className="space-y-6">
                <div className="bg-gradient-to-br from-black to-red-900/20 p-8 rounded-2xl border border-red-800/30">
                  <h3 className="text-2xl font-bold text-white mb-4">Как мы строили империю</h3>
                  <div className="space-y-4">
                    <div className="flex items-start space-x-4">
                      <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center text-sm font-bold">1</div>
                      <div>
                        <h4 className="font-semibold text-red-400">Основание</h4>
                        <p className="text-gray-400 text-sm">Создание семьи с четкой иерархией</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-4">
                      <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center text-sm font-bold">2</div>
                      <div>
                        <h4 className="font-semibold text-red-400">Расширение</h4>
                        <p className="text-gray-400 text-sm">Захват ключевых территорий города</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-4">
                      <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center text-sm font-bold">3</div>
                      <div>
                        <h4 className="font-semibold text-red-400">Доминирование</h4>
                        <p className="text-gray-400 text-sm">Полный контроль над сферами влияния</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Members Section */}
      {activeSection === 'members' && (
        <section className="min-h-screen pt-24 px-6">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-5xl font-bold text-center mb-16 bg-gradient-to-r from-red-500 to-yellow-400 bg-clip-text text-transparent">
              Участники семьи
            </h2>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {members.map((member, index) => (
                <div key={index} className="group relative">
                  <div className="bg-gradient-to-br from-red-900/30 to-black/70 p-6 rounded-2xl border border-red-800/30 backdrop-blur-sm hover:border-red-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-red-500/20">
                    <div className="relative mb-6">
                      <img 
                        src={member.image} 
                        alt={member.name}
                        className="w-20 h-20 rounded-full mx-auto border-4 border-red-500/50 group-hover:border-red-500 transition-all duration-300"
                      />
                      <div className="absolute -top-2 -right-2 w-6 h-6 bg-green-500 rounded-full border-2 border-black"></div>
                    </div>
                    
                    <div className="text-center">
                      <h3 className="text-xl font-bold text-white mb-2">{member.name}</h3>
                      <p className="text-red-400 font-semibold mb-2">{member.role}</p>
                      <span className="inline-block px-3 py-1 bg-yellow-600/20 text-yellow-400 rounded-full text-sm border border-yellow-600/30">
                        {member.status}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-16 text-center">
              <div className="bg-gradient-to-r from-red-900/30 to-yellow-900/30 p-8 rounded-2xl border border-red-800/30 inline-block">
                <h3 className="text-2xl font-bold text-white mb-4">Хочешь присоединиться?</h3>
                <p className="text-gray-300 mb-6 max-w-md">
                  Мы всегда ищем достойных людей, которые готовы стать частью легенды
                </p>
                <div className="flex justify-center space-x-4">
                  <div className="flex items-center space-x-2 text-red-400">
                    <Phone className="h-5 w-5" />
                    <span>Связь в игре</span>
                  </div>
                  <div className="flex items-center space-x-2 text-yellow-400">
                    <Mail className="h-5 w-5" />
                    <span>Discord сервер</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* News Section */}
      {activeSection === 'news' && (
        <section className="min-h-screen pt-24 px-6">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-5xl font-bold text-center mb-16 bg-gradient-to-r from-red-500 to-yellow-400 bg-clip-text text-transparent">
              Последние новости
            </h2>
            
            <div className="space-y-8">
              <div className="bg-gradient-to-br from-red-900/30 to-black/70 p-8 rounded-2xl border border-red-800/30 backdrop-blur-sm">
                <div className="flex items-center space-x-3 mb-4">
                  <Calendar className="h-5 w-5 text-red-400" />
                  <span className="text-red-400 font-semibold">15 января 2025</span>
                </div>
                <h3 className="text-2xl font-bold text-white mb-4">Успешная операция по расширению территории</h3>
                <p className="text-gray-300 leading-relaxed">
                  Семья Raze успешно установила контроль над новым районом в центре города. 
                  Операция прошла без потерь с нашей стороны, что еще раз доказывает наше превосходство.
                </p>
                <div className="mt-4 flex space-x-2">
                  <span className="px-3 py-1 bg-green-600/20 text-green-400 rounded-full text-sm">Успех</span>
                  <span className="px-3 py-1 bg-red-600/20 text-red-400 rounded-full text-sm">Территория</span>
                </div>
              </div>
              
              <div className="bg-gradient-to-br from-yellow-900/30 to-black/70 p-8 rounded-2xl border border-yellow-800/30 backdrop-blur-sm">
                <div className="flex items-center space-x-3 mb-4">
                  <Calendar className="h-5 w-5 text-yellow-400" />
                  <span className="text-yellow-400 font-semibold">10 января 2025</span>
                </div>
                <h3 className="text-2xl font-bold text-white mb-4">Новые участники в семье</h3>
                <p className="text-gray-300 leading-relaxed">
                  К нам присоединились 5 новых членов семьи, прошедших строгий отбор. 
                  Каждый из них доказал свою преданность и готовность следовать кодексу семьи.
                </p>
                <div className="mt-4 flex space-x-2">
                  <span className="px-3 py-1 bg-blue-600/20 text-blue-400 rounded-full text-sm">Расширение</span>
                  <span className="px-3 py-1 bg-purple-600/20 text-purple-400 rounded-full text-sm">Новички</span>
                </div>
              </div>
              
              <div className="bg-gradient-to-br from-green-900/30 to-black/70 p-8 rounded-2xl border border-green-800/30 backdrop-blur-sm">
                <div className="flex items-center space-x-3 mb-4">
                  <Calendar className="h-5 w-5 text-green-400" />
                  <span className="text-green-400 font-semibold">5 января 2025</span>
                </div>
                <h3 className="text-2xl font-bold text-white mb-4">Альянс с влиятельными семьями</h3>
                <p className="text-gray-300 leading-relaxed">
                  Заключен стратегический альянс с двумя другими влиятельными организациями города. 
                  Это укрепляет наши позиции и открывает новые возможности для развития.
                </p>
                <div className="mt-4 flex space-x-2">
                  <span className="px-3 py-1 bg-purple-600/20 text-purple-400 rounded-full text-sm">Альянс</span>
                  <span className="px-3 py-1 bg-blue-600/20 text-blue-400 rounded-full text-sm">Дипломатия</span>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Footer */}
      <footer className="bg-black/50 border-t border-red-800/30 py-8">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <Crown className="h-6 w-6 text-red-500" />
            <span className="text-xl font-bold bg-gradient-to-r from-red-500 to-yellow-400 bg-clip-text text-transparent">
              RAZE FAMILY
            </span>
          </div>
          <p className="text-gray-400">
            © 2025 Raze Family | Majestic RP | Все права защищены
          </p>
          <p className="text-sm text-gray-500 mt-2">
            "Семья - это не только кровь. Это те, кто готов за тебя умереть."
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;